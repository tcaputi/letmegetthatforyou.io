define({
	google: {
		oauth: {
			clientId: "71035194058.apps.googleusercontent.com",
			applicationType: "Chrome App",
			applicationId: "lboenahmopojppcnjgbippkdjdlkbmje"
		},
		projectNumber: 71035194058,
		projectId: "courier-app"
	},
	backend: {
		protocol: "http",
		domain: "localhost",
		port: 7373,
		url: protocol + "//" + domain + ":" + port
	}
});